New gopher face for gopei installer available from version 1.0.4.0+ Worked in [Gimp](http://www.gimp.org/).
